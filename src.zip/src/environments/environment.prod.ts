export const environment = {
  production: true,
  apiEndPoint:'http://localhost:3000/',
  logEndPont:'http://localhost:7070',

  authEndPoint:'http://localhost:7070/oauth/token',
  buildName:'Prod'
};
