import { Show } from './show';
export class Config {
    data:any;
    results:Show[];
}
