export class Origin {
    name: string;
    url: string
}
