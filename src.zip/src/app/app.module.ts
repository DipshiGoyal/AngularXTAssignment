import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CharacterListComponent } from './characters/components/character-list/character-list.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CharacterSearchComponent } from './characters/components/character-search/character-search.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CharacterFilterComponent } from './characters/components/character-filter/character-filter.component';

import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [
    AppComponent,
    CharacterListComponent,
    CharacterSearchComponent,
    CharacterFilterComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule


  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
